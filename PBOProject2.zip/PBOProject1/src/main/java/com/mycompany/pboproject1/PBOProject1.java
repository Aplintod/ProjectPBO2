/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pboproject1;

/**
 *
 * @author HP
 */
public class PBOProject1 {

    public static void main(String[] args) {
        manajer manajer = new manajer();
        int pilihan;
        
        do {
            System.out.println("Pipin Self Photo Studio");
            System.out.println("1. Tambah Sesi Foto");
            System.out.println("2. Tampilkan Sesi Foto");
            System.out.println("3. Ubah Status Pembayaran");
            System.out.println("4. Hapus Sesi Foto");
            System.out.println("5. Keluar");
            System.out.println("Pilihan Opsi : ");
            pilihan =  new java.util.Scanner(System.in).nextInt();
            new java.util.Scanner(System.in).nextLine();
            
            switch (pilihan) {
                case 1:
                    manajer.tambahSesiFoto();
                    break;
                case 2:
                    manajer.tampilkanSemuaSesi();
                    break;
                case 3:
                    manajer.ubahStatusPembayaran();
                    break;
                case 4:
                    manajer.hapusSesiFoto();
                    break;
                case 5:
                    System.out.println("Terimakasih Telah Menggunakan Layanan Kami");
                    break;
                default:
                    System.out.println("Pilihan Tidak Valid");
            }
        } while (pilihan != 5);
    }
}
