/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pboproject1;

import com.customer.customer;
import com.customer.VipCustomer;
import com.customer.RegularCustomer;
import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author HP
 */
public class manajer implements CRUD {
    private static final ArrayList<customer> sesiFoto = new ArrayList<>();
    private static final Scanner scanner = new Scanner(System.in);
    
    @Override
    public void tambahSesiFoto() {
        System.out.println("Nama Customer : ");
        String nama = scanner.nextLine();
        System.out.println("Durasi Sesi Foto (15/30/60/90 menit) : ");
        int durasi = scanner.nextInt();
        System.out.println("Apakah Customer VIP? (y/n)");
        scanner.nextLine();
        String isVip = scanner.nextLine();
        double harga = durasi * 3000;
        
        if (isVip.equalsIgnoreCase("y")) {
            VipCustomer vipCustomer = new VipCustomer(nama, durasi, harga, 0.1);
            sesiFoto.add(vipCustomer);
        } else {
            RegularCustomer regularCustomer = new RegularCustomer(nama, durasi, harga);
            sesiFoto.add(regularCustomer);
        }
        System.out.println("Sesi Foto Ditambahkan.");
    }
    
    @Override
    public void tampilkanSemuaSesi() {
        if (sesiFoto.isEmpty()) {
            System.out.println("Sesi Foto Kosong.");
        } else {
            for (customer session : sesiFoto) {
                session.cetakInvoice();
                System.out.println();
            }
        }
        
    }
    
    @Override
    public void ubahStatusPembayaran() {
        System.out.println("Masukkan Nama Pelanggan : ");
        String nama = scanner.nextLine();
        for (customer session :sesiFoto) {
            if (session.getNamaCustomer().equalsIgnoreCase(nama)) {
                session.setStatusPembayaran("Sudah Bayar");
                System.out.println("Status pembayaran untuk " + nama + " telah diubah.");
                return;
            }
        }
        System.out.println("Pelanggan Tidak Ditemukan.");
    }
    
    @Override
    public void hapusSesiFoto() {
        System.out.println("Masukkan Nama Customer : ");
        String nama = scanner.nextLine();
        for (int i = 0; i < sesiFoto.size(); i++) {
            if (sesiFoto.get(i).getNamaCustomer().equalsIgnoreCase(nama)) {
                sesiFoto.remove(i);
                System.out.println("Sesi Foto untuk" + nama + "telah dihapus.");
                return;
            }
        }
        System.out.println("Customer Tidak Ditemukan.");
    }
    
}
