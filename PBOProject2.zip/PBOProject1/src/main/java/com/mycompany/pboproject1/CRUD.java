/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.pboproject1;

/**
 *
 * @author HP
 */
public interface CRUD {
    void tambahSesiFoto();
    void tampilkanSemuaSesi();
    void ubahStatusPembayaran();
    void hapusSesiFoto();
}
