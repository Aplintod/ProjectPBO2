/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.customer;

/**
 *
 * @author HP
 */
public class customer extends session {
    private String statusPembayaran;
    
    public customer(String namaCustomer, int durasi, double harga) {
        super(namaCustomer, durasi, harga);
        this.statusPembayaran = "Belum Bayar";
    }
    
    @Override
    public void cetakInvoice() {
            System.out.println("Nama Customer : " + getNamaCustomer());
            System.out.println("Durasi Sesi Foto : " + getDurasi() + " menit");
            System.out.println("Total Harga : " + getHarga());
            System.out.println("Status Pembayaran : " + statusPembayaran);
    }
    
    public String getStatusPembayaran() {
        return statusPembayaran;
    }
    
    public void setStatusPembayaran(String statusPembayaran) {
        this.statusPembayaran = statusPembayaran;
    }
}
