/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.customer;

/**
 *
 * @author HP
 */
public class RegularCustomer extends customer {
    
    public RegularCustomer(String namaCustomer, int durasi, double harga) {
        super(namaCustomer, durasi, harga);
    }
    
    @Override
    public void cetakInvoice() {
        System.out.println("Nama Customer Regular : " + getNamaCustomer());
        System.out.println("Durasi Sesi Foto : " + getDurasi() + " Menit");
        System.out.println("Total Harga : " + getHarga());
        System.out.println("Status Pembayaran : " + getStatusPembayaran());
    }
    
}
