/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.customer;

/**
 *
 * @author HP
 */
public class VipCustomer extends customer{
    private double diskon;
    
    public VipCustomer(String namaCustomer, int durasi, double harga, double diskon) {
        super(namaCustomer, durasi, harga);
        this.diskon = diskon;
    }
    
    @Override
    public void cetakInvoice() {
        double hargaDiskon = getHarga() - (getHarga() * diskon);
        System.out.println("Nama Customer VIP : " + getNamaCustomer());
        System.out.println("Durasi Sesi Foto : " + getDurasi() + " Menit");
        System.out.println("Total Harga (Diskon) : " + hargaDiskon);
        System.out.println("Status Pembayaran : " + getStatusPembayaran());
    }
}
