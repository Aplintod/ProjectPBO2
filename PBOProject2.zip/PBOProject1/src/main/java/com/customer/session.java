/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.customer;

/**
 *
 * @author HP
 */
public abstract class session {
    private final String namaCustomer;
    private final int durasi;
    private final double harga;
    
    public session(String namaCustomer, int durasi, double harga) {
        this.namaCustomer = namaCustomer;
        this.durasi = durasi;
        this.harga = harga;
    }
    
    public String getNamaCustomer() {
        return namaCustomer;
    }
    
    public int getDurasi() {
        return durasi;
    }
    
    public double getHarga() {
        return harga;
    }
    
    public abstract void cetakInvoice();
}
